HIGHWAY RACING — ANDROID STUDIO PROJECT

App title: Highway Racing
Developer display name: Divyanshu
Package ID: com.divyanshu.highwayracing

WHAT THIS IS
An Android WebView wrapper around the included offline HTML highway racing prototype. It includes traffic, touch steering, nitro, score/coins and a simple police cruiser visual/chase theme. It is a 2D canvas / 2.5D-style prototype, not a full 3D game.

BUILD
1. Extract this ZIP.
2. Install Android Studio, JDK 17, Android SDK Platform 36 and Build Tools.
3. Open this folder in Android Studio.
4. Wait for Gradle sync.
5. For local testing: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. For Play Store: Build > Generate Signed Bundle / APK > Android App Bundle. Create and safely store your upload key.

BEFORE PLAY STORE
Read PLAY_STORE_CHECKLIST_HI.txt and PLAY_STORE_LISTING_HI.txt. Host the privacy policy template at a public HTTPS URL after adding a real support email. Test the finished app and provide real screenshots, icon and feature graphic. Complete all Play Console declarations truthfully.

IMPORTANT
This is source code, not a compiled APK/AAB. It has not been device-tested or approved by Google Play. Google Play submission requirements can change.

MOBILE-ONLY CLOUD BUILD (GitHub Actions)
1. GitHub par naya repository banayein (Public ya Private).
2. Is ZIP ko phone me extract karein.
3. Extracted project ke andar ke saare files/folders (including hidden .github folder) repository ke main page par Add file > Upload files se upload karein, phir Commit changes.
4. Repository me Actions tab kholein. 'Build Android AAB' workflow ko select karke Run workflow dabayein (ya main branch par push ke baad automatic run hoga).
5. Successful run ke Artifacts section se highway-racing-aab-unsigned.zip download karein aur extract karein.

IMPORTANT: Is workflow ka AAB UNSIGNED hai. Ye test/build output hai; ise seedha Google Play Console par upload NA karein. Play Store upload ke liye apni private upload keystore se AAB sign karna hoga. Keystore aur passwords ko kabhi public repository me upload na karein. Signing setup agle step me karein.
